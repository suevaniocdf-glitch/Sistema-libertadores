# Sistema Libertadores — Firebase + Netlify

App de gestão de colportagem (React + Vite) com persistência no **Firebase Firestore**.

## Estrutura

```
sistema-libertadores-firebase/
├── index.html
├── package.json
├── vite.config.js
├── netlify.toml
├── .gitignore
└── src/
    ├── main.jsx        # entrada (carrega o storage antes do app)
    ├── firebase.js     # conexão com o Firebase + CRUD por coleção
    ├── storage.js      # adaptador: window.storage -> Firestore
    └── sistema.jsx      # o app completo
```

Como funciona: o app grava tudo via `window.storage`. O `storage.js` reimplementa
essa API em cima do Firestore, então **todo o app passa a usar o Firebase** sem
reescrever nada. Cada chave vira um documento na coleção `appState`.

---

## 1) Configurar o Firestore (uma vez)

1. Acesse o [Console do Firebase](https://console.firebase.google.com/) →
   projeto **acompanhamento-libertadores**.
2. Menu **Build → Firestore Database → Criar banco de dados**.
3. Escolha **iniciar em modo de teste** (libera leitura/escrita por ~30 dias) e
   uma região (ex.: `southamerica-east1`).
4. (Recomendado depois) Em **Regras**, defina o acesso. Para começar:

   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /{document=**} {
         allow read, write: if true;   // MODO DE TESTE
       }
     }
   }
   ```

   > Em produção, proteja com **Firebase Authentication** (login) antes de
   > permitir escrita.

---

## 2) Rodar localmente

Pré-requisito: **Node.js 18+**.

```bash
npm install
npm run dev
```

Abra o endereço que o Vite mostrar (ex.: `http://localhost:5173`).
Para testar a versão de produção:

```bash
npm run build
npm run preview
```

---

## 3) Publicar no Netlify

### Opção A — pelo Git (recomendado, faz deploy automático a cada push)

1. Suba a pasta para um repositório no **GitHub** (ou GitLab/Bitbucket):
   ```bash
   git init
   git add .
   git commit -m "Sistema Libertadores + Firebase"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/SEU_REPO.git
   git push -u origin main
   ```
2. Entre no [Netlify](https://app.netlify.com/) → **Add new site → Import an existing project**.
3. Escolha o provedor (GitHub) e selecione o repositório.
4. O Netlify lê o `netlify.toml` e já preenche:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
5. Clique em **Deploy site**. Pronto — a cada `git push` ele republica sozinho.

### Opção B — arrastar e soltar (deploy manual rápido)

1. Gere a build local:
   ```bash
   npm install
   npm run build
   ```
2. No Netlify, vá em **Sites** e **arraste a pasta `dist`** para a área de deploy
   ("Drag and drop your site output folder here").
3. O site fica no ar em segundos. (Para atualizar, refaça o build e arraste a
   `dist` de novo.)

### Opção C — Netlify CLI

```bash
npm install -g netlify-cli
npm run build
netlify deploy --prod --dir=dist
```

---

## 4) Liberar o domínio no Firebase (Auth, se usar)

Se mais tarde você ativar o **Firebase Authentication**, adicione o domínio do
Netlify (ex.: `seu-site.netlify.app`) em **Authentication → Settings → Authorized
domains**. Só para Firestore (sem Auth) isso não é necessário.

---

## Observações

- A `apiKey` no `firebase.js` é pública por natureza num app web — a segurança
  vem das **regras do Firestore**.
- Os dados são compartilhados entre todos os usuários (diretor, líderes e
  colportores veem a mesma base), que é o comportamento esperado do sistema.
- Quer documentos por registro (ex.: cada colportor num doc próprio) em vez do
  modelo de "estado por chave"? O `firebase.js` já traz um CRUD (`colportores.create/list/update/remove`) pronto para isso.
